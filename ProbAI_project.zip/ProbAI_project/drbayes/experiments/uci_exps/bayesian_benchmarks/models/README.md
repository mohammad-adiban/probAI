To add a model create a new folder and add a file models.py that implements the model. 

See template.py for the model API.

Add the name of your model to `get_models.py` under `all_regression_models` or `all_classification_models` as appropriate. 
