Mohammad Adiban: mohammad.adiban@ntnu.no
PhD candidate
Department of Electronic Systems

########################################

How to execute the codes:

MNF Method (Method 2)
python3 -m main --dataset ./wine.txt --method 2
python3 -m main --dataset ./protein.txt --method 2
...


SWAG Method (Method 3)
python3 -m main --dataset ./wine.txt --method 3
python3 -m main --dataset ./protein.txt --method 3
...

Improvement on SWAG (Proposed Method):
python3 -m main --dataset ./wine.txt --method 0
python3 -m main --dataset ./protein.txt --method 0
...